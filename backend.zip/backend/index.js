import express from "express";
import cors from "cors"
import multer from "multer";

import assignroutes1 from "./Models/RAboutUs.js"
import assignroutes2 from "./Models/RAdmin.js"
import assignroutes3 from "./Models/RAssignTask.js"
import assignroutes4 from "./Models/RContactUs.js"
import assignroutes5 from "./Models/RManageCareer.js"
import assignroutes6 from "./Models/RManageEmployee.js"
import assignroutes7 from "./Models/RManageProject.js"
import assignroutes8 from "./Models/RManageServices.js"
import assignroutes9 from "./Models/RManageTesting.js"
import assignroutes10 from "./Models/RMessageToEmpolyee.js"
import assignroutes11 from "./Models/RProjectRequirement.js"
import assignroutes12 from "./Models/RSlider.js"
import assignroutes13 from "./Models/RLogin.js"
import assignroutes14 from "./Models/Rtester_login.js"
import assignroutes15 from "./Models/Rdeveloper_login.js"


const app= express()
app.use(express.json())
app.use(cors())

app.use("/backend/aboutus",assignroutes1)
app.use("/backend/admin",assignroutes2)
app.use("/backend/Assigntask",assignroutes3)
app.use("/backend/contactus",assignroutes4)
app.use("/backend/manageCareer",assignroutes5)
app.use("/backend/ManageEmployee",assignroutes6)
app.use("/backend/ManageProject",assignroutes7)
app.use("/backend/Manageservices",assignroutes8)
app.use("/backend/Managetesting",assignroutes9)
app.use("/backend/Messagetoemployee",assignroutes10)
app.use("/backend/projectrequirement",assignroutes11)
app.use("/backend/slider",assignroutes12)
app.use("/backend/login",assignroutes13)
app.use("/backend/login_tester",assignroutes14)
app.use("/backend/login_developer",assignroutes15)
app.listen(8800,()=>{
    console.log("Connected to Backend")
})


const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "../client/public/upload");
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + file.originalname);
  },
});

const upload = multer({ storage });

app.post("/backend/upload", upload.single("file"), function (req, res) {
  const file = req.file;
  res.status(200).json(file.filename);
});